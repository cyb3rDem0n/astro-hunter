# Correzione dei due difetti emersi dal pilota

```bash
cd astro-hunter
unzip -o astro-hunter-agent-fix.zip -d .
cat docs/D-030-031-append.md >> docs/decisions.md
rm docs/D-030-031-append.md APPLY.md

python -m pytest -q -m "not network"      # 138 attesi
python -m ruff check .
```

I test nuovi **falliscono contro il codice precedente** — ho verificato che
coprano davvero i due bug e non passino per caso.

## Poi rilancia il pilota

```bash
python -u scripts/20_agent_triage.py --pilot --out runs/pilot2.json
```

Circa 40 centesimi. Salva su un file diverso così puoi confrontare.

Cosa deve cambiare:
- **zero run senza verdetto** (prima erano 2 su 12)
- **molti meno `contaminated`** (prima 5 su 12, su quattro disposizioni diverse)

Se un run fallisce ancora, ora lo vedi elencato in fondo con il motivo, invece
di doverlo cercare.

```bash
git add -A
git commit -m "fix: validate the submitted verdict and explain the exclusion bound

Two defects from the first pilot. The verdict field carried a long prose
description inside an enum and the model sometimes omitted it, producing
runs that reported themselves completed while returning nothing. And the
prompt did not state that max_producible_depth_ppm excludes a neighbour
but never accuses one, so the agent returned contaminated for almost
anything with a neighbour.

Records D-030 and D-031.
"
git push
```

## Cosa ho sbagliato, per chiarezza

**Sullo schema.** Avevo messo una descrizione lunga e discorsiva dentro un
campo `enum`. È il tipo di dettaglio che si verifica solo facendo girare la
cosa, ma la validazione del valore restituito avrei dovuto scriverla da subito:
è una regola generale, non una reazione a questo caso.

**Sul prompt.** Avevo spiegato *cosa calcola* lo strumento senza spiegare *come
si legge*. Il numero esclude con certezza e non accusa mai, e quella asimmetria
è l'intero valore del controllo.
