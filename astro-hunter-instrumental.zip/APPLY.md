# instrumental.py — coincidenza con il record osservativo

```bash
cd astro-hunter
unzip -o astro-hunter-instrumental.zip -d .
cat docs/D-020-append.md >> docs/decisions.md
rm docs/D-020-append.md APPLY.md

python -m pytest -q -m "not network"      # 54 passati
python -m ruff check .
```

Nessun test di rete stavolta: il modulo non interroga niente. Tutti e 16 i test
girano offline in tre secondi.

```bash
git add -A
git commit -m "feat: instrumental coincidence checks from the observing record

Evidence path for FA. Assesses whether a signal's predicted transits
coincide with flagged cadences, fall in data gaps, or lack coverage -
computed from the light curve's own timestamps and SPOC quality flags,
with no network access.

Records D-020.
"
git push
```

## Perché non è una query

I momentum dump, le finestre di scattered light e i bordi di orbita sono già
registrati cadenza per cadenza nella colonna di qualità SPOC. Andarli a
raschiare dalle release note li riprodurrebbe peggio.

Ma soprattutto: la domanda che serve non è "in questo settore c'è stato un
evento", è "**i transiti di questo segnale** ci coincidono". È una proprietà
dell'effemeride contro il record osservativo, e si può rispondere solo dove ci
sono entrambi.

## I tre controlli

**Coincidenza con cadenze marcate.** Una ricerca cieca non sa nulla del
satellite, quindi una periodicità nel pattern di osservazione le è
indistinguibile da una periodicità nella stella.

**Coincidenza con i gap.** I gap sono periodici — downlink d'orbita, bordi di
settore — quindi una ricerca può agganciare un periodo che colloca i transiti
dentro di essi. Il segnale rivelatore è che i transiti previsti risultano in
gran parte non osservati: quel periodo è un alias della finestra osservativa.

**Copertura insufficiente.** Un evento coperto fissa un'epoca, mai un periodo:
qualsiasi periodo il cui transito successivo cade fuori dalla baseline si adatta
altrettanto bene. Per questo i transiti previsti e quelli effettivamente
osservati sono contati separatamente e riportati entrambi.

## Una scelta sui flag

Bitmask 30895, letto da `lightkurve.utils.TessQualityFlags` e non scritto a
mano. Esclusi di proposito i raggi cosmici e gli outlier impulsivi: sono eventi
di singola cadenza che la pulizia già rimuove, e contarli qui marcherebbe dati
sani come strumentali. C'è un test che protegge questa scelta.

## Un test che era sbagliato

`test_too_few_covered_transits` inizialmente falliva: avevo scritto una baseline
di 8 giorni con periodo 6,27, dentro cui stanno due transiti — esattamente il
minimo richiesto. Il codice aveva ragione, il test no. Ora usa 5 giorni.
