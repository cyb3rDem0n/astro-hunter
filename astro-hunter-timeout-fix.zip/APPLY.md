# Correzione: timeout sulle query e salvataggio incrementale

Il blocco di prima era un difetto reale del codice, non un capriccio di Gaia.

```bash
cd astro-hunter
unzip -o astro-hunter-timeout-fix.zip -d .
cat docs/D-028-029-append.md >> docs/decisions.md
rm docs/D-028-029-append.md APPLY.md

python -m pytest -q -m "not network"      # 128 attesi
python -m ruff check .
```

Poi riprova il pilota:

```bash
python -u scripts/20_agent_triage.py --pilot --out runs/pilot.json
```

Il `-u` fa comparire le righe in tempo reale invece che tutte alla fine.

Aggiungi `runs/` al `.gitignore` prima di committare: sono output rigenerabili.

```bash
git add -A
git commit -m "fix: time out archive requests instead of hanging

An agent run stopped mid-batch inside an SSL read against a service that
accepted the connection and then went quiet. requests has no global
timeout, so pyvo waited indefinitely and the process could not be
interrupted.

Results are now also written after each signal, so an interrupted batch
is a partial result rather than a total loss.

Records D-028 and D-029.
"
git push
```

## Cosa è cambiato

**`core/http.py`** — nuovo. Una sessione HTTP che applica 60 secondi di timeout
a ogni richiesta. I tre moduli che interrogano archivi la usano.

Perché serviva: `requests` non ha un timeout globale, è un parametro per
chiamata. Una libreria che chiama al posto tuo, come fa pyvo, aspetta
all'infinito se nessuno glielo dice.

Il punto non è la scomodità. Un lotto da 600 candidati non può fermarsi per un
servizio che non risponde. Il timeout trasforma il silenzio in un errore — e
con gli errori il codice sa già cosa fare: diventano `insufficient`, non
risposte sbagliate.

**`scripts/20_agent_triage.py`** — scrive il file di output dopo ogni segnale,
non alla fine. Se un lotto si interrompe, quello che hai già pagato resta.
