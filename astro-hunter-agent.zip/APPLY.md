# L'agente

```bash
cd astro-hunter
unzip -o astro-hunter-agent.zip -d .
cat docs/D-027-append.md >> docs/decisions.md
rm docs/D-027-append.md APPLY.md
```

Aggiungi `anthropic` a `pyproject.toml`, nella lista `dependencies`:

```toml
    "anthropic>=1.0",
```

```bash
python -m pip install -e ".[dev]"
python -m pytest -q -m "not network"      # 124 attesi (108 + 16 nuovi)
python -m ruff check .
```

I 16 test nuovi girano contro un client finto: verificano il loop, i tre
guardrail e tutti i percorsi di errore **senza spendere un centesimo**.

## Primo: la stima, senza chiamare l'API

```bash
python scripts/20_agent_triage.py --pilot --dry-run
```

Elenca i 12 candidati che verrebbero processati (due per disposizione) e stima
il costo. Nessuna chiamata fatta.

## Poi: la chiave API

Su Windows, in Git Bash:

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

Vale solo per quella finestra di terminale. Per renderla permanente la metti
nelle variabili d'ambiente di Windows.

**La chiave non va mai in un file del repo.** Se ti scappa un commit con una
chiave dentro, va revocata subito dalla Console: una volta su GitHub è
compromessa anche se la cancelli dopo.

## Poi: un solo candidato

```bash
python scripts/20_agent_triage.py --toi TOI-4329.01 --verbose
```

Un solo segnale, con il ragionamento stampato. Costa circa 4 centesimi. È il
primo momento in cui vedi l'agente lavorare davvero.

## Poi: il pilota

```bash
python scripts/20_agent_triage.py --pilot --out runs/pilot.json
```

I 12 candidati, circa 45 centesimi. Salva i risultati per il confronto con le
regole.

Aggiungi `runs/` al `.gitignore`: sono output rigenerabili, non codice.

```bash
git add -A
git commit -m "feat: agent loop over the triage tools

A model reasoning over the MCP tools, with an iteration ceiling, a token
budget and result truncation. The verdict is submitted through a tool so
the output is structured by construction rather than parsed from prose.

Failures are recorded as outcomes: a batch of six hundred signals must
not stop because one failed.

Records D-027.
"
git push
```

## Cosa guardare nel pilota

Non solo se i verdetti sono giusti. Anche:

- **quanti turni** usa in media. Se ne usa uno solo, non sta consultando gli
  strumenti. Se ne usa otto, qualcosa non si chiude.
- **se il ragionamento cita gli strumenti**. Deve dire da dove viene ogni
  numero. Se afferma cose senza fonte, il prompt va stretto.
- **i casi FP e KP**. Sono quelli dove le regole non arrivano, ed è lì che
  l'agente deve dimostrare di servire a qualcosa.
