
---

## D-030 — A verdict is validated, and the exclusion bound is explained

**Both defects found in the first real pilot run**, at a cost of $0.41.

### The verdict was silently lost

Two of twelve runs recorded `stop_reason: completed` with `verdict: null`,
while carrying a confidence of 0.97, a full reasoning paragraph and an evidence
list. The model had called `submit_verdict` and omitted only the verdict field.

*Cause.* The `verdict` property carried a long prose description inside an enum
field, listing and explaining all six values. The other three fields, with short
descriptions, arrived every time.

*Fixes, both needed.* The explanation moved to the tool description, leaving
`verdict` as a bare enum. And the returned value is now validated against the
enum: anything else records `stop_reason: invalid_verdict` with the offending
value in `error`.

The second fix matters more than the first. A required field in a schema is not
a guarantee, so the loop must not assume one. A run that reports itself as
completed while producing nothing is worse than a run that fails, because it is
paid for and looks successful — which is exactly how it survived a pilot
unnoticed.

Whatever did arrive is kept, so the run can still be inspected.

### "Cannot be excluded" was read as "is guilty"

Five of twelve runs returned `contaminated`, spanning four different true
dispositions including a planet candidate. The reasoning was explicit about
why: a neighbour could produce a depth larger than the observed one, "meaning
it cannot be excluded as the true source".

*Cause.* The prompt described what `max_producible_depth_ppm` is without
stating that it is informative in one direction only.

The bound is the deepest dip a neighbour could cause if totally eclipsed. Below
the observed depth it *excludes* that neighbour with certainty. Above it,
nothing is established — and almost every neighbour clears that bar, because a
star four magnitudes fainter still reaches tens of thousands of ppm. Used as
evidence of guilt, the check condemns nearly every signal ever observed.

*Fix.* The prompt now states the asymmetry explicitly, says that
`could_explain_signal: true` means NOT EXCLUDED rather than GUILTY, and names
the two conditions that do positively indicate contamination: a target holding
a small fraction of the aperture flux beside a much brighter star, or a
dilution-corrected depth that is physically impossible for a planet.

*Note.* One run reached the second condition unaided, observing that a
corrected depth of roughly 485,000 ppm would be absurd for a planetary transit.
That is a physical deduction none of the deterministic rules can make, and it
is the kind of reasoning the agent is meant to contribute.

**Status.** Active. Both regressions covered by tests that fail against the
previous behaviour.

---

## D-031 — Runs without a verdict are listed at the end of a batch

**Decision.** The batch script prints every run that produced no verdict, with
its stop reason and error.

**Rationale.** The two lost verdicts appeared in the per-signal output as
`[completed]` in the position where a verdict belongs — visible, but easy to
read past in a list of twelve. Paid-for failures should be stated as failures,
in one place, at the end.

**Status.** Active.
